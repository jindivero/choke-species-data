As of 2/15/2023,

1) The raw .hex files for .asc files have not been found in OCNMS files.
2) The SBE19_2997_2009.con does not have the fluorometer and beam transmissometer in it, but yet 4 voltages are selected for CTD*.hex files.