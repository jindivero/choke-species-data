Notes:
1) The 2007 CTD instrument suite (SBE19 SN 2997) used a YSI oxygen sensor.  I am not familiar with it all, and did not verify that its calibration coefficients were in the 2997.con file already.  Its "final" calibration sheet is included in the zip files for your review.

2) 2007_nonSBE19.zip contents:  I cannot remember if I described what I believe these files to be....  They used to attach the mooring instruments to the CTD/SBE19 SN 2997 system/rosette and send down for direct, internal "calibration" work versus trying to match up CTD profile data with mooring data.

3) There are FL_Site_MMDDYY_CAST files in the 2007_nonSBE19.zip.  I do not remember fluorometer calibration check files in 2008 or 2009.  These have their own calibration coefficients, which are currently NOT included.  Let me know if you are using these *CAST data...

Also, as a reminder, the CTD instrument suite, when it is the SBE19 SN 2997, theoretically also has a CStar beam transmissometer and Seapoint fluorometer on it.  For 2007, 2008, and 2009, the coefficients are NOT currently included in the .con files.
