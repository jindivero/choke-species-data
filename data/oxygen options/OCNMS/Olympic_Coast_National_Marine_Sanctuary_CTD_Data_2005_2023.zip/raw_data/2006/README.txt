March 23, 2023 - KRH

It appears the oddly named files are really CTD casts, i.e. profiles done with SBE19 SN2997.  All files in this 2006.zip were verified to be this unit.

Two casts were done at CE015 on 05/30/2006.  Based on the filenames, assumption is one was done with the large mooring DO instrument attached to the CTD for direct instrument comparison.  The other cast was done with the mooring fluorometer attached to the CTD.

Some files have comments regarding 'Mooring Site Instrument comparison' within them, and a couple are named as such.